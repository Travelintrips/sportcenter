/*
  # Add Email Notification Trigger for User Registration

  1. Changes
    - Add trigger function for user registration
    - Create trigger on profiles table
    - Add notification handling
    
  2. Security
    - Maintain proper access control
    - Ensure data integrity
*/

-- Create trigger function for user registration
CREATE OR REPLACE FUNCTION handle_user_signup()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  -- Insert welcome email notification
  INSERT INTO email_notifications (
    recipient_email,
    recipient_name,
    type,
    data,
    status
  ) VALUES (
    (SELECT email FROM auth.users WHERE id = NEW.id),
    NEW.full_name,
    'welcome_email',
    jsonb_build_object(
      'fullName', NEW.full_name
    ),
    'pending'
  );
  
  RETURN NEW;
END;
$$;

-- Create trigger
DROP TRIGGER IF EXISTS on_user_signup ON profiles;
CREATE TRIGGER on_user_signup
  AFTER INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION handle_user_signup();