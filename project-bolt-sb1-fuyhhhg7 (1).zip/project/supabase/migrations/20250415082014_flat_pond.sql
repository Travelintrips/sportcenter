/*
  # Create avatars storage bucket

  1. New Storage Bucket
    - Create a new bucket named 'avatars' for storing profile avatars
  
  2. Security
    - Enable public access for reading avatars
    - Allow authenticated users to upload avatars
    - Allow users to manage their own avatars
*/

-- Create the avatars bucket if it doesn't exist
insert into storage.buckets (id, name, public)
values ('avatars', 'avatars', true)
on conflict (id) do nothing;

-- Allow public access to read avatars
create policy "Public can view avatars"
on storage.objects for select
to public
using ( bucket_id = 'avatars' );

-- Allow authenticated users to upload avatars
create policy "Authenticated users can upload avatars"
on storage.objects for insert
to authenticated
with check ( bucket_id = 'avatars' );

-- Allow users to manage their own avatars
create policy "Users can manage own avatars"
on storage.objects for all
to authenticated
using ( bucket_id = 'avatars' );