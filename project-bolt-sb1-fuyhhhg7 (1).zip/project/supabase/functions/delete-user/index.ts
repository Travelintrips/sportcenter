import { createClient } from 'npm:@supabase/supabase-js@2.39.7'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    )

    const { userId } = await req.json()

    if (!userId) {
      throw new Error('User ID is required')
    }

    // First check if the requesting user is a super_admin
    const authHeader = req.headers.get('Authorization')?.split(' ')[1]
    if (!authHeader) {
      throw new Error('No authorization token provided')
    }

    const { data: { user: requestingUser }, error: authError } = await supabase.auth.getUser(authHeader)
    if (authError || !requestingUser) {
      throw new Error('Invalid authorization token')
    }

    // Get the requesting user's role
    const { data: requestingUserProfile, error: profileError } = await supabase
      .from('profiles')
      .select('role:roles(name)')
      .eq('id', requestingUser.id)
      .single()

    if (profileError || !requestingUserProfile?.role?.name) {
      throw new Error('Could not verify user role')
    }

    if (requestingUserProfile.role.name !== 'super_admin') {
      throw new Error('Only super administrators can delete users')
    }

    // Delete the user's profile first
    const { error: profileDeleteError } = await supabase
      .from('profiles')
      .delete()
      .eq('id', userId)

    if (profileDeleteError) {
      throw profileDeleteError
    }

    // Then delete the user from auth
    const { error: userDeleteError } = await supabase.auth.admin.deleteUser(userId)

    if (userDeleteError) {
      throw userDeleteError
    }

    return new Response(
      JSON.stringify({ message: 'User deleted successfully' }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      },
    )
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      },
    )
  }
})