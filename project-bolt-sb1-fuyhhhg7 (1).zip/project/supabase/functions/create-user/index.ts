import { createClient } from 'npm:@supabase/supabase-js@2.39.7'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    )

    const { email, password, full_name, role_id, phone_number } = await req.json()

    if (!email || !password || !full_name || !role_id) {
      throw new Error('Missing required fields')
    }

    // First check if the requesting user is an admin or super_admin
    const authHeader = req.headers.get('Authorization')?.split(' ')[1]
    if (!authHeader) {
      throw new Error('No authorization token provided')
    }

    const { data: { user: requestingUser }, error: authError } = await supabase.auth.getUser(authHeader)
    if (authError || !requestingUser) {
      throw new Error('Invalid authorization token')
    }

    // Get the requesting user's role
    const { data: requestingUserProfile, error: profileError } = await supabase
      .from('profiles')
      .select('role:roles(name)')
      .eq('id', requestingUser.id)
      .single()

    if (profileError || !requestingUserProfile?.role?.name) {
      throw new Error('Could not verify user role')
    }

    if (!['admin', 'super_admin'].includes(requestingUserProfile.role.name)) {
      throw new Error('Only administrators can create users')
    }

    // Create the user with admin client
    const { data: { user }, error: createError } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { full_name }
    })

    if (createError) throw createError
    if (!user) throw new Error('Failed to create user')

    // Create the profile
    const { error: profileCreateError } = await supabase
      .from('profiles')
      .insert({
        id: user.id,
        full_name,
        email,
        phone_number,
        role_id,
        is_active: true
      })

    if (profileCreateError) {
      // Rollback user creation if profile creation fails
      await supabase.auth.admin.deleteUser(user.id)
      throw profileCreateError
    }

    return new Response(
      JSON.stringify({ message: 'User created successfully', user }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      },
    )
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      },
    )
  }
})