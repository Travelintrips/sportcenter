import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.7";
import nodemailer from "npm:nodemailer@6.9.12";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Fetch all pending email notifications
    const { data: notifications, error: fetchError } = await supabaseClient
      .from("email_notifications")
      .select("*")
      .eq("status", "pending")
      .order("created_at", { ascending: true });

    if (fetchError) throw fetchError;
    if (!notifications || notifications.length === 0) {
      return new Response(
        JSON.stringify({ message: "No pending notifications" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 }
      );
    }

    // Create Nodemailer transporter
    const transporter = nodemailer.createTransport({
      host: Deno.env.get("SMTP_HOST"),
      port: Number(Deno.env.get("SMTP_PORT")),
      secure: false,
      auth: {
        user: Deno.env.get("SMTP_USER"),
        pass: Deno.env.get("SMTP_PASS"),
      },
    });

    for (const notification of notifications) {
      const { recipient_email, recipient_name, type, data } = notification;

      let emailContent = '';
      let subject = '';

      if (type === 'booking_confirmation') {
        subject = 'Booking Confirmation';
        emailContent = `
          <html>
          <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
              <h2 style="color: #2563eb;">Booking Confirmation</h2>
              <p>Dear ${recipient_name},</p>
              <p>Thank you for booking with us. Your booking has been confirmed!</p>
              <div style="background-color: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <h3 style="color: #1f2937; margin-top: 0;">Booking Details:</h3>
                <ul style="list-style: none; padding: 0;">
                  <li style="margin-bottom: 10px;"><strong>Facility:</strong> ${data.facilityName}</li>
                  <li style="margin-bottom: 10px;"><strong>Start Time:</strong> ${data.startTime}</li>
                  <li style="margin-bottom: 10px;"><strong>End Time:</strong> ${data.endTime}</li>
                  <li style="margin-bottom: 10px;"><strong>Total Price:</strong> ${data.totalPrice}</li>
                  <li style="margin-bottom: 10px;"><strong>Booking Reference:</strong> ${data.bookingReference}</li>
                </ul>
              </div>
              <p>If you have any questions, please contact our support team.</p>
              <p style="margin-top: 30px;">Best regards,<br>Sports Center Team</p>
            </div>
          </body>
          </html>
        `;
      } else if (type === 'welcome_email') {
        subject = 'Welcome to Sports Center';
        emailContent = `
          <html>
          <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
              <h2 style="color: #2563eb;">Welcome to Sports Center!</h2>
              <p>Dear ${recipient_name},</p>
              <p>Thank you for registering with us. We're excited to have you as a member!</p>
              <div style="background-color: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <p style="margin-top: 0;">With your account, you can:</p>
                <ul style="list-style: none; padding: 0;">
                  <li style="margin-bottom: 10px;">✓ Book sports facilities</li>
                  <li style="margin-bottom: 10px;">✓ Manage your bookings</li>
                  <li style="margin-bottom: 10px;">✓ View your booking history</li>
                  <li style="margin-bottom: 10px;">✓ And much more!</li>
                </ul>
              </div>
              <p>If you have any questions or need assistance, don't hesitate to contact our support team.</p>
              <p style="margin-top: 30px;">Best regards,<br>Sports Center Team</p>
            </div>
          </body>
          </html>
        `;
      }

      // Send email using Nodemailer
      await transporter.sendMail({
        from: `"Sports Center" <${Deno.env.get("SMTP_USER")}>`,
        to: recipient_email,
        subject: subject,
        html: emailContent,
      });

      // Update email status
      await supabaseClient
        .from("email_notifications")
        .update({ status: "sent", processed_at: new Date().toISOString() })
        .eq("id", notification.id);
    }

    return new Response(
      JSON.stringify({ message: "All emails sent successfully" }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      }
    );
  } catch (error) {
    console.error("Error sending emails:", error);

    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500,
      }
    );
  }
});