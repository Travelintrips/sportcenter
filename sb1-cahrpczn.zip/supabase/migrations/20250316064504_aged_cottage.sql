/*
  # Add Email Notifications Table (Safe Version)

  1. Changes
    - Create email_notifications table if it doesn't exist
    - Drop existing policies before creating new ones
    - Add policies for both authenticated and public access
    
  2. Security
    - Enable RLS
    - Add policies for inserting notifications
    - Handle existing policy cleanup
*/

-- Create email_notifications table if it doesn't exist
CREATE TABLE IF NOT EXISTS email_notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_email text NOT NULL,
  recipient_name text NOT NULL,
  type text NOT NULL,
  data jsonb NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  processed_at timestamptz,
  CONSTRAINT valid_status CHECK (status IN ('pending', 'sent', 'failed'))
);

-- Enable RLS
ALTER TABLE email_notifications ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can insert email notifications" ON email_notifications;
  DROP POLICY IF EXISTS "Public can insert email notifications" ON email_notifications;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new policies
CREATE POLICY "Users can insert email notifications"
  ON email_notifications
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Public can insert email notifications"
  ON email_notifications
  FOR INSERT
  TO public
  WITH CHECK (true);