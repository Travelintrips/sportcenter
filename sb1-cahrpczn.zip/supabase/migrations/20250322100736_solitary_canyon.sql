/*
  # Fix Email Notifications Constraints and Add Booking Reference

  1. Changes
    - Remove unique constraints from email_notifications table
    - Add booking_reference column if not exists
    - Add performance index for status and created_at
    - Add error_log column for tracking failures
    
  2. Security
    - Maintain data integrity
    - Improve query performance
    - Better error tracking
*/

-- Add booking_reference column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'email_notifications' 
    AND column_name = 'booking_reference'
  ) THEN
    ALTER TABLE email_notifications
    ADD COLUMN booking_reference text;
  END IF;
END $$;

-- Add error_log column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'email_notifications' 
    AND column_name = 'error_log'
  ) THEN
    ALTER TABLE email_notifications
    ADD COLUMN error_log text;
  END IF;
END $$;

-- Drop existing unique constraints if they exist
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1
    FROM information_schema.table_constraints
    WHERE constraint_name = 'unique_email_booking'
    AND table_name = 'email_notifications'
  ) THEN
    ALTER TABLE email_notifications
    DROP CONSTRAINT unique_email_booking;
  END IF;
END $$;

-- Drop existing indexes if they exist
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_indexes
    WHERE indexname = 'email_notifications_unique'
  ) THEN
    DROP INDEX email_notifications_unique;
  END IF;

  IF EXISTS (
    SELECT 1
    FROM pg_indexes
    WHERE indexname = 'email_notifications_unique_ref'
  ) THEN
    DROP INDEX email_notifications_unique_ref;
  END IF;
END $$;

-- Create new performance index
CREATE INDEX IF NOT EXISTS idx_email_notifications_status 
ON email_notifications(status);