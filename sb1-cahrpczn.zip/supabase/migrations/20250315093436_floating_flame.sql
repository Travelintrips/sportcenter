/*
  # Add Email Notifications Table

  1. New Tables
    - `email_notifications`
      - `id` (uuid, primary key)
      - `recipient_email` (text)
      - `recipient_name` (text)
      - `type` (text)
      - `data` (jsonb)
      - `status` (text)
      - `created_at` (timestamp)
      - `processed_at` (timestamp)

  2. Security
    - Enable RLS
    - Add policies for inserting notifications
*/

-- Create email_notifications table
CREATE TABLE IF NOT EXISTS email_notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_email text NOT NULL,
  recipient_name text NOT NULL,
  type text NOT NULL,
  data jsonb NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  processed_at timestamptz,
  CONSTRAINT valid_status CHECK (status IN ('pending', 'sent', 'failed'))
);

-- Enable RLS
ALTER TABLE email_notifications ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users to insert notifications
CREATE POLICY "Users can insert email notifications"
  ON email_notifications
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Allow public to insert notifications (for guest bookings)
CREATE POLICY "Public can insert email notifications"
  ON email_notifications
  FOR INSERT
  TO public
  WITH CHECK (true);