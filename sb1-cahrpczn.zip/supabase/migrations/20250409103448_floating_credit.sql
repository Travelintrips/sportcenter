/*
  # Create Sports Facilities Table

  1. Changes
    - Create sports_facilities table if not exists
    - Add RLS policies with proper checks
    - Insert initial data
    
  2. Security
    - Enable RLS
    - Add proper access policies with safety checks
*/

-- Create the table
CREATE TABLE IF NOT EXISTS sports_facilities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  price_per_hour integer,
  price_per_day integer,
  price_per_month integer,
  image_url text,
  booking_type text DEFAULT 'per_hour',
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE sports_facilities ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Public facilities access" ON sports_facilities;
  DROP POLICY IF EXISTS "Authenticated facilities access" ON sports_facilities;
  DROP POLICY IF EXISTS "Admin and super admin can manage facilities" ON sports_facilities;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create policy for public read access
CREATE POLICY "Public facilities access"
  ON sports_facilities
  FOR SELECT
  TO public
  USING (true);

-- Create policy for authenticated read access
CREATE POLICY "Authenticated facilities access"
  ON sports_facilities
  FOR SELECT
  TO authenticated
  USING (true);

-- Create policy for admin management
CREATE POLICY "Admin and super admin can manage facilities"
  ON sports_facilities
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      JOIN roles r ON r.id = p.role_id
      WHERE p.id = auth.uid()
      AND r.name IN ('admin', 'super_admin')
    )
  );

-- Insert initial data
INSERT INTO sports_facilities (
  name,
  description,
  price_per_hour,
  image_url,
  booking_type
) VALUES 
(
  'Indoor Basketball Court',
  'Professional-grade indoor basketball court with wooden flooring and adjustable hoops',
  50000,
  'https://images.unsplash.com/photo-1546519638-68e109498ffc?auto=format&fit=crop&q=80&w=1200',
  'per_hour'
),
(
  'Tennis Court',
  'All-weather tennis court with night lighting',
  40000,
  'https://images.unsplash.com/photo-1622279457486-62dcc4a431d6?auto=format&fit=crop&q=80&w=1200',
  'per_hour'
),
(
  'Futsal Court',
  'Indoor futsal court with artificial turf',
  60000,
  'https://images.unsplash.com/photo-1577223625816-7546f13df25d?auto=format&fit=crop&q=80&w=1200',
  'per_hour'
),
(
  'Gym',
  'Fully equipped gym with modern fitness equipment',
  25000,
  'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80&w=1200',
  'per_day'
)
ON CONFLICT (id) DO NOTHING;