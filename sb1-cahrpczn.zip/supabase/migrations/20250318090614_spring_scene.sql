/*
  # Fix Email Notification Trigger

  1. Changes
    - Update trigger to handle email notifications properly
    - Add proper error handling
    - Ensure notifications are processed correctly
    
  2. Security
    - Maintain existing security policies
    - Ensure proper access control
*/

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS send_booking_email ON email_notifications;

-- Create new trigger for sending emails
CREATE TRIGGER send_booking_email
  AFTER INSERT OR UPDATE OF status
  ON email_notifications
  FOR EACH ROW
  EXECUTE FUNCTION supabase_functions.http_request(
    'https://kzibrbcrqbknckjbdrtc.supabase.co/functions/v1/send-booking-confirmation',
    'POST',
    '{"Content-type":"application/json"}',
    '{}',
    '5000'
  );

-- Update email notifications table to ensure status field exists
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'email_notifications' 
    AND column_name = 'status'
  ) THEN
    ALTER TABLE email_notifications
    ADD COLUMN status text NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'sent', 'failed'));
  END IF;
END $$;

-- Add index for better performance
CREATE INDEX IF NOT EXISTS idx_email_notifications_status 
ON email_notifications(status);