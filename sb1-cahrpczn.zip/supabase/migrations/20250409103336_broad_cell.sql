/*
  # Update sports facilities table schema

  1. Changes
    - Add required columns for facility management:
      - price_per_hour (integer)
      - price_per_day (integer)
      - price_per_month (integer)
      - image_url (text)
      - booking_type (text)
      - pricing_type (text)
    
  2. Security
    - Maintain existing RLS policies
*/

-- Add new columns to sports_facilities table
ALTER TABLE sports_facilities 
ADD COLUMN IF NOT EXISTS price_per_hour integer,
ADD COLUMN IF NOT EXISTS price_per_day integer,
ADD COLUMN IF NOT EXISTS price_per_month integer,
ADD COLUMN IF NOT EXISTS image_url text,
ADD COLUMN IF NOT EXISTS booking_type text DEFAULT 'per_hour',
ADD COLUMN IF NOT EXISTS pricing_type text DEFAULT 'per_hour';

-- Add constraint for booking_type
ALTER TABLE sports_facilities
ADD CONSTRAINT valid_booking_type 
CHECK (booking_type IN ('per_hour', 'per_day'));

-- Add constraint for pricing_type
ALTER TABLE sports_facilities
ADD CONSTRAINT valid_pricing_type 
CHECK (pricing_type IN ('per_hour', 'per_visit'));

-- Insert sample data
INSERT INTO sports_facilities (
  name, 
  description, 
  price_per_hour,
  image_url,
  booking_type
) VALUES 
(
  'Indoor Basketball Court',
  'Professional-grade indoor basketball court with wooden flooring and adjustable hoops',
  50000,
  'https://images.unsplash.com/photo-1546519638-68e109498ffc?auto=format&fit=crop&q=80&w=1200',
  'per_hour'
),
(
  'Tennis Court',
  'All-weather tennis court with night lighting',
  40000,
  'https://images.unsplash.com/photo-1622279457486-62dcc4a431d6?auto=format&fit=crop&q=80&w=1200',
  'per_hour'
),
(
  'Futsal Court',
  'Indoor futsal court with artificial turf',
  60000,
  'https://images.unsplash.com/photo-1577223625816-7546f13df25d?auto=format&fit=crop&q=80&w=1200',
  'per_hour'
),
(
  'Gym',
  'Fully equipped gym with modern fitness equipment',
  25000,
  'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80&w=1200',
  'per_day'
)
ON CONFLICT (id) DO NOTHING;