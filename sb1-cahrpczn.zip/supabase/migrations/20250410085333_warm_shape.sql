-- Drop existing function if it exists
DROP FUNCTION IF EXISTS update_booking_group_status;

-- Create function to update booking group status
CREATE OR REPLACE FUNCTION update_booking_group_status(ref text, new_status text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Validate status
  IF new_status NOT IN ('pending', 'confirmed', 'cancelled') THEN
    RAISE EXCEPTION 'Invalid status: %', new_status;
  END IF;

  -- Update all bookings with the same reference
  UPDATE bookings
  SET 
    status = new_status,
    updated_at = CURRENT_TIMESTAMP
  WHERE 
    guest_reference = ref
    OR id IN (
      -- Get all related bookings in the same group
      SELECT b2.id
      FROM bookings b1
      JOIN bookings b2 ON 
        b1.guest_reference = b2.guest_reference
        AND b1.guest_reference = ref
    );

  -- Notify about the status change
  PERFORM pg_notify(
    'booking_status_changed',
    json_build_object(
      'guest_reference', ref,
      'status', new_status,
      'updated_at', CURRENT_TIMESTAMP
    )::text
  );
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION update_booking_group_status(text, text) TO authenticated;

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_bookings_guest_reference 
ON bookings(guest_reference) 
WHERE guest_reference IS NOT NULL;