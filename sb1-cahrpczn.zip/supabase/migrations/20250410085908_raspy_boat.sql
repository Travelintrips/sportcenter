-- Drop existing function if it exists
DROP FUNCTION IF EXISTS update_booking_group_status;

-- Create function to update booking group status
CREATE OR REPLACE FUNCTION update_booking_group_status(ref text, new_status text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  first_booking_id uuid;
  first_booking_user_id uuid;
  first_booking_facility_id uuid;
  first_booking_time time;
BEGIN
  -- Validate status
  IF new_status NOT IN ('pending', 'confirmed', 'cancelled') THEN
    RAISE EXCEPTION 'Invalid status: %', new_status;
  END IF;

  -- Get the first booking's details to find related bookings
  SELECT 
    id,
    user_id,
    facility_id,
    CAST(start_time::time AS time)
  INTO
    first_booking_id,
    first_booking_user_id,
    first_booking_facility_id,
    first_booking_time
  FROM bookings
  WHERE guest_reference = ref
  LIMIT 1;

  -- Update all related bookings
  UPDATE bookings
  SET 
    status = new_status,
    updated_at = CURRENT_TIMESTAMP
  WHERE 
    -- Match by guest reference for guest bookings
    (guest_reference IS NOT NULL AND guest_reference = ref)
    OR
    -- Match by user, facility, and time for member bookings
    (
      user_id = first_booking_user_id
      AND facility_id = first_booking_facility_id
      AND CAST(start_time::time AS time) = first_booking_time
      AND id != first_booking_id
      AND DATE_PART('dow', start_time) = DATE_PART('dow', (SELECT start_time FROM bookings WHERE id = first_booking_id))
    );

  -- Notify about the status change
  PERFORM pg_notify(
    'booking_status_changed',
    json_build_object(
      'reference', ref,
      'status', new_status,
      'updated_at', CURRENT_TIMESTAMP
    )::text
  );
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION update_booking_group_status(text, text) TO authenticated;

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_bookings_guest_reference 
ON bookings(guest_reference) 
WHERE guest_reference IS NOT NULL;

-- Create index for finding related bookings
CREATE INDEX IF NOT EXISTS idx_bookings_user_facility_time
ON bookings(user_id, facility_id, start_time);