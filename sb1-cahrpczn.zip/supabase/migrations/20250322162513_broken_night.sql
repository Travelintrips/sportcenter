/*
  # Add Staff Role and Update Permissions

  1. Changes
    - Add 'staff' role to roles table
    - Update existing policies to include staff role
    
  2. Security
    - Maintain proper access control
    - Enable staff functionality
*/

-- Insert staff role if it doesn't exist
INSERT INTO roles (name)
SELECT 'staff'
WHERE NOT EXISTS (SELECT 1 FROM roles WHERE name = 'staff');

-- Update is_admin function to include staff role
CREATE OR REPLACE FUNCTION is_admin_or_super_admin(user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM roles r, profiles p
    WHERE p.id = user_id
    AND p.role_id = r.id
    AND r.name IN ('admin', 'super_admin', 'staff')
  );
$$;