/*
  # Update Sports Facilities Table

  1. Changes
    - Add new columns and constraints
    - Update existing data
    - Add RLS policies
    
  2. Security
    - Maintain existing foreign key relationships
    - Enable proper access control
*/

-- Add new columns if they don't exist
ALTER TABLE sports_facilities 
ADD COLUMN IF NOT EXISTS description text,
ADD COLUMN IF NOT EXISTS price_per_hour integer,
ADD COLUMN IF NOT EXISTS price_per_day integer,
ADD COLUMN IF NOT EXISTS price_per_month integer,
ADD COLUMN IF NOT EXISTS image_url text,
ADD COLUMN IF NOT EXISTS booking_type text DEFAULT 'per_hour',
ADD COLUMN IF NOT EXISTS pricing_type text DEFAULT 'per_hour',
ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now(),
ADD COLUMN IF NOT EXISTS updated_at timestamptz DEFAULT now();

-- Add constraints
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'valid_booking_type'
  ) THEN
    ALTER TABLE sports_facilities
    ADD CONSTRAINT valid_booking_type 
    CHECK (booking_type IN ('per_hour', 'per_day'));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'valid_pricing_type'
  ) THEN
    ALTER TABLE sports_facilities
    ADD CONSTRAINT valid_pricing_type 
    CHECK (pricing_type IN ('per_hour', 'per_visit'));
  END IF;
END $$;

-- Enable RLS if not already enabled
ALTER TABLE sports_facilities ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Public can view facilities" ON sports_facilities;
  DROP POLICY IF EXISTS "Authenticated can view facilities" ON sports_facilities;
  DROP POLICY IF EXISTS "Admins can manage facilities" ON sports_facilities;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new policies
CREATE POLICY "Public can view facilities"
  ON sports_facilities
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated can view facilities"
  ON sports_facilities
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage facilities"
  ON sports_facilities
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      JOIN roles r ON r.id = p.role_id
      WHERE p.id = auth.uid()
      AND r.name IN ('admin', 'super_admin')
    )
  );

-- Update or insert sample data
INSERT INTO sports_facilities (
  name, 
  description, 
  price_per_hour,
  image_url,
  booking_type
) VALUES 
(
  'Indoor Basketball Court',
  'Professional-grade indoor basketball court with wooden flooring and adjustable hoops',
  50000,
  'https://images.unsplash.com/photo-1546519638-68e109498ffc?auto=format&fit=crop&q=80&w=1200',
  'per_hour'
),
(
  'Tennis Court',
  'All-weather tennis court with night lighting',
  40000,
  'https://images.unsplash.com/photo-1622279457486-62dcc4a431d6?auto=format&fit=crop&q=80&w=1200',
  'per_hour'
),
(
  'Futsal Court',
  'Indoor futsal court with artificial turf',
  60000,
  'https://images.unsplash.com/photo-1577223625816-7546f13df25d?auto=format&fit=crop&q=80&w=1200',
  'per_hour'
),
(
  'Gym',
  'Fully equipped gym with modern fitness equipment',
  25000,
  'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80&w=1200',
  'per_day'
)
ON CONFLICT (id) DO 
  UPDATE SET
    name = EXCLUDED.name,
    description = EXCLUDED.description,
    price_per_hour = EXCLUDED.price_per_hour,
    image_url = EXCLUDED.image_url,
    booking_type = EXCLUDED.booking_type,
    updated_at = now();