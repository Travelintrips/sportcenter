/*
  # Fix Admin User Management Access

  1. Changes
    - Update RLS policies to allow admin access to user management
    - Add policies for admin role to manage users
    - Fix policy conditions for proper access control
    
  2. Security
    - Maintain proper access control
    - Enable admin functionality
    - Ensure data integrity
*/

-- Update is_admin function to include admin role
CREATE OR REPLACE FUNCTION is_admin(user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM roles r, profiles p
    WHERE p.id = user_id
    AND p.role_id = r.id
    AND r.name IN ('admin', 'super_admin')
  );
$$;

-- Update is_admin_or_super_admin function
CREATE OR REPLACE FUNCTION is_admin_or_super_admin(user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM roles r, profiles p
    WHERE p.id = user_id
    AND p.role_id = r.id
    AND r.name IN ('admin', 'super_admin')
  );
$$;

-- Drop existing policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "allow_read_own_and_admin_read_all" ON profiles;
  DROP POLICY IF EXISTS "allow_update_own_and_admin_update_all" ON profiles;
  DROP POLICY IF EXISTS "allow_insert_own_profile" ON profiles;
  DROP POLICY IF EXISTS "service_role_all_access" ON profiles;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new policies for user management
CREATE POLICY "allow_read_own_and_admin_read_all"
ON profiles
FOR SELECT
TO authenticated
USING (
  id = auth.uid() OR
  is_admin_or_super_admin(auth.uid())
);

CREATE POLICY "allow_update_own_and_admin_update_all"
ON profiles
FOR UPDATE
TO authenticated
USING (
  id = auth.uid() OR
  is_admin_or_super_admin(auth.uid())
)
WITH CHECK (
  id = auth.uid() OR
  is_admin_or_super_admin(auth.uid())
);

CREATE POLICY "allow_insert_own_profile"
ON profiles
FOR INSERT
TO authenticated
WITH CHECK (
  id = auth.uid() OR
  is_admin_or_super_admin(auth.uid())
);

CREATE POLICY "allow_delete_for_admins"
ON profiles
FOR DELETE
TO authenticated
USING (is_admin_or_super_admin(auth.uid()));

-- Service role policy
CREATE POLICY "service_role_all_access"
ON profiles
FOR ALL
TO service_role
USING (true)
WITH CHECK (true);