/*
  # Fix Admin Access Policies

  1. Changes
    - Update RLS policies to properly handle admin access
    - Allow admins to manage facilities and users
    - Fix policy conditions for admin role
    
  2. Security
    - Maintain proper access control
    - Enable admin functionality
    - Ensure data integrity
*/

-- Update is_admin function to include admin role
CREATE OR REPLACE FUNCTION is_admin(user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM roles r, profiles p
    WHERE p.id = user_id
    AND p.role_id = r.id
    AND r.name IN ('admin', 'super_admin')
  );
$$;

-- Update is_admin_or_super_admin function
CREATE OR REPLACE FUNCTION is_admin_or_super_admin(user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM roles r, profiles p
    WHERE p.id = user_id
    AND p.role_id = r.id
    AND r.name IN ('admin', 'super_admin')
  );
$$;

-- Drop existing policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Super admin can manage facilities" ON sports_facilities;
  DROP POLICY IF EXISTS "Admin and super admin can manage facilities" ON sports_facilities;
  DROP POLICY IF EXISTS "Anyone can view facilities" ON sports_facilities;
  DROP POLICY IF EXISTS "Public facilities access" ON sports_facilities;
  DROP POLICY IF EXISTS "Authenticated facilities access" ON sports_facilities;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new policies for facilities management
CREATE POLICY "Admin and super admin can manage facilities"
ON sports_facilities
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles p
    JOIN roles r ON r.id = p.role_id
    WHERE p.id = auth.uid()
    AND r.name IN ('admin', 'super_admin')
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM profiles p
    JOIN roles r ON r.id = p.role_id
    WHERE p.id = auth.uid()
    AND r.name IN ('admin', 'super_admin')
  )
);

-- Allow public read access
CREATE POLICY "Public facilities access"
ON sports_facilities
FOR SELECT
TO public
USING (true);

-- Allow authenticated read access
CREATE POLICY "Authenticated facilities access"
ON sports_facilities
FOR SELECT
TO authenticated
USING (true);

-- Update profiles policies for admin access
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "allow_read_own_and_admin_read_all" ON profiles;
  DROP POLICY IF EXISTS "allow_update_own_and_admin_update_all" ON profiles;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new profiles policies
CREATE POLICY "allow_read_own_and_admin_read_all"
ON profiles
FOR SELECT
TO authenticated
USING (
  id = auth.uid() OR
  is_admin_or_super_admin(auth.uid())
);

CREATE POLICY "allow_update_own_and_admin_update_all"
ON profiles
FOR UPDATE
TO authenticated
USING (
  id = auth.uid() OR
  is_admin_or_super_admin(auth.uid())
)
WITH CHECK (
  id = auth.uid() OR
  is_admin_or_super_admin(auth.uid())
);