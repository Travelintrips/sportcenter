/*
  # Update Facilities Management Access

  1. Changes
    - Allow admin role to manage facilities
    - Update RLS policies for facilities table
    
  2. Security
    - Maintain existing security policies
    - Add admin access to facilities management
*/

-- Drop existing policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Super admin can manage facilities" ON sports_facilities;
  DROP POLICY IF EXISTS "Anyone can view facilities" ON sports_facilities;
  DROP POLICY IF EXISTS "Allow public read access to facilities" ON sports_facilities;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new policies for facilities management
CREATE POLICY "Admin and super admin can manage facilities"
ON sports_facilities
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles p
    JOIN roles r ON r.id = p.role_id
    WHERE p.id = auth.uid()
    AND r.name IN ('admin', 'super_admin')
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM profiles p
    JOIN roles r ON r.id = p.role_id
    WHERE p.id = auth.uid()
    AND r.name IN ('admin', 'super_admin')
  )
);

-- Allow public read access
CREATE POLICY "Public facilities access"
ON sports_facilities
FOR SELECT
TO public
USING (true);

-- Allow authenticated read access
CREATE POLICY "Authenticated facilities access"
ON sports_facilities
FOR SELECT
TO authenticated
USING (true);