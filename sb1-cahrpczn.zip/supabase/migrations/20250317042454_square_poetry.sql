/*
  # Add is_active column to profiles table

  1. Changes
    - Add is_active column to profiles table
    - Set default value to true
    - Update existing rows
*/

-- Add is_active column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'profiles' 
    AND column_name = 'is_active'
  ) THEN
    ALTER TABLE profiles
    ADD COLUMN is_active boolean DEFAULT true;
  END IF;
END $$;

-- Update existing rows to have is_active = true
UPDATE profiles
SET is_active = true
WHERE is_active IS NULL;