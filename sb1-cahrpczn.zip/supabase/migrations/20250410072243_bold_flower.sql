/*
  # Add Booking Group Status Update Function

  1. Changes
    - Add PostgreSQL function to update booking group status
    - Handle status updates for all bookings in a group
    
  2. Security
    - Function runs with RLS policies
    - Maintains proper access control
*/

-- Create function to update booking group status
CREATE OR REPLACE FUNCTION update_booking_group_status(ref text, new_status text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Validate status
  IF new_status NOT IN ('pending', 'confirmed', 'cancelled') THEN
    RAISE EXCEPTION 'Invalid status: %', new_status;
  END IF;

  -- Update all bookings with the same reference
  UPDATE bookings
  SET status = new_status
  WHERE guest_reference = ref;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION update_booking_group_status(text, text) TO authenticated;