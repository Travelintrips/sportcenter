/*
  # Add Secure User Data Access

  1. Changes
    - Create function to safely access user data
    - Create secure view for user information
    - Add proper security checks
    
  2. Security
    - Only allow access to authorized users
    - Maintain data privacy
    - Ensure proper access control
*/

-- Create function to safely get user email
CREATE OR REPLACE FUNCTION get_user_email(user_id uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_email text;
BEGIN
  -- Check if the requesting user is authorized
  IF auth.uid() = user_id OR EXISTS (
    SELECT 1 FROM profiles p
    JOIN roles r ON r.id = p.role_id
    WHERE p.id = auth.uid()
    AND r.name = 'super_admin'
  ) THEN
    -- Get email from auth.users
    SELECT email INTO user_email
    FROM auth.users
    WHERE id = user_id;
    
    RETURN user_email;
  END IF;
  
  RETURN NULL;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION get_user_email(uuid) TO authenticated;

-- Create a function to check if user has access to view data
CREATE OR REPLACE FUNCTION can_view_user_data(target_user_id uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT 
    auth.uid() = target_user_id OR
    EXISTS (
      SELECT 1 FROM profiles p
      JOIN roles r ON r.id = p.role_id
      WHERE p.id = auth.uid()
      AND r.name = 'super_admin'
    );
$$;

-- Create a secure function to get user data
CREATE OR REPLACE FUNCTION get_user_data(target_user_id uuid)
RETURNS TABLE (
  id uuid,
  full_name text,
  email text,
  created_at timestamptz,
  is_active boolean,
  phone_number text,
  role_id uuid,
  role_name text
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF can_view_user_data(target_user_id) THEN
    RETURN QUERY
    SELECT 
      p.id,
      p.full_name,
      get_user_email(p.id),
      p.created_at,
      p.is_active,
      p.phone_number,
      r.id as role_id,
      r.name as role_name
    FROM profiles p
    JOIN roles r ON r.id = p.role_id
    WHERE p.id = target_user_id;
  END IF;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION get_user_data(uuid) TO authenticated;

-- Create a secure function to list all users (for super_admin)
CREATE OR REPLACE FUNCTION list_users()
RETURNS TABLE (
  id uuid,
  full_name text,
  email text,
  created_at timestamptz,
  is_active boolean,
  phone_number text,
  role_id uuid,
  role_name text
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM profiles p
    JOIN roles r ON r.id = p.role_id
    WHERE p.id = auth.uid()
    AND r.name = 'super_admin'
  ) THEN
    RETURN QUERY
    SELECT 
      p.id,
      p.full_name,
      get_user_email(p.id),
      p.created_at,
      p.is_active,
      p.phone_number,
      r.id as role_id,
      r.name as role_name
    FROM profiles p
    JOIN roles r ON r.id = p.role_id;
  END IF;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION list_users() TO authenticated;