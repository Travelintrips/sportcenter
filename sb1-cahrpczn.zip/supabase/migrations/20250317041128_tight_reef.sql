/*
  # Add Members Role

  1. Changes
    - Add 'members' role to roles table
    - Update existing role-related policies
    
  2. Security
    - Maintain existing security policies
    - Ensure proper access control for new role
*/

-- Insert members role if it doesn't exist
INSERT INTO roles (name)
SELECT 'members'
WHERE NOT EXISTS (SELECT 1 FROM roles WHERE name = 'members');

-- Update is_admin function to recognize members role
CREATE OR REPLACE FUNCTION is_admin(user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM roles r, profiles p
    WHERE p.id = user_id
    AND p.role_id = r.id
    AND r.name IN ('admin', 'super_admin', 'members')
  );
$$;

-- Update is_admin_or_super_admin function to include members
CREATE OR REPLACE FUNCTION is_admin_or_super_admin(user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM roles r, profiles p
    WHERE p.id = user_id
    AND p.role_id = r.id
    AND r.name IN ('admin', 'super_admin', 'members')
  );
$$;