/*
  # Add updated_at column to bookings table

  1. Changes
    - Add `updated_at` column to `bookings` table with default value of now()
    - Add trigger to automatically update `updated_at` on row updates
*/

-- Add updated_at column
ALTER TABLE bookings 
ADD COLUMN updated_at timestamptz DEFAULT now();

-- Create function to update timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger to automatically update timestamp
CREATE TRIGGER update_bookings_updated_at
    BEFORE UPDATE ON bookings
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();