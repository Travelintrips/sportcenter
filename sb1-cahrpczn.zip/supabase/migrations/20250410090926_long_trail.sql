/*
  # Fix Group Booking Status Updates

  1. Changes
    - Update SQL function to properly handle both guest and member bookings
    - Add proper indexing for performance
    - Ensure all related bookings are updated
    
  2. Security
    - Maintain proper access control
    - Add error handling
*/

-- Drop existing function if it exists
DROP FUNCTION IF EXISTS update_booking_group_status;

-- Create function to update booking group status
CREATE OR REPLACE FUNCTION update_booking_group_status(booking_id uuid, new_status text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  target_booking RECORD;
BEGIN
  -- Validate status
  IF new_status NOT IN ('pending', 'confirmed', 'cancelled') THEN
    RAISE EXCEPTION 'Invalid status: %', new_status;
  END IF;

  -- Get the target booking details
  SELECT 
    id,
    user_id,
    facility_id,
    guest_reference,
    start_time,
    CAST(start_time::time AS time) as booking_time
  INTO target_booking
  FROM bookings
  WHERE id = booking_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Booking not found';
  END IF;

  -- Update all related bookings
  WITH bookings_to_update AS (
    SELECT b.id
    FROM bookings b
    WHERE 
      -- For guest bookings, match by guest_reference
      (
        target_booking.guest_reference IS NOT NULL 
        AND b.guest_reference = target_booking.guest_reference
      )
      OR
      -- For member bookings, match by user, facility, and time pattern
      (
        target_booking.guest_reference IS NULL
        AND b.user_id = target_booking.user_id
        AND b.facility_id = target_booking.facility_id
        AND CAST(b.start_time::time AS time) = target_booking.booking_time
        AND DATE_PART('dow', b.start_time) = DATE_PART('dow', target_booking.start_time)
        AND b.start_time >= target_booking.start_time
      )
  )
  UPDATE bookings b
  SET 
    status = new_status,
    updated_at = CURRENT_TIMESTAMP
  FROM bookings_to_update btu
  WHERE b.id = btu.id;

  -- Notify about the status change
  PERFORM pg_notify(
    'booking_status_changed',
    json_build_object(
      'booking_id', booking_id,
      'status', new_status,
      'updated_at', CURRENT_TIMESTAMP
    )::text
  );
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION update_booking_group_status(uuid, text) TO authenticated;

-- Create or replace indexes for better performance
DROP INDEX IF EXISTS idx_bookings_guest_reference;
CREATE INDEX idx_bookings_guest_reference 
ON bookings(guest_reference) 
WHERE guest_reference IS NOT NULL;

DROP INDEX IF EXISTS idx_bookings_user_facility_time;
CREATE INDEX idx_bookings_user_facility_time
ON bookings(user_id, facility_id, start_time);