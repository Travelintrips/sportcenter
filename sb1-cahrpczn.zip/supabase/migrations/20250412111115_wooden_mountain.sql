/*
  # Create logos storage bucket

  1. New Storage Bucket
    - Create a new bucket named 'logos' for storing invoice logos
  
  2. Security
    - Enable public access for reading logos
    - Allow authenticated users to upload logos
    - Allow authenticated admins to delete logos
*/

-- Create the logos bucket if it doesn't exist
insert into storage.buckets (id, name, public)
values ('logos', 'logos', true)
on conflict (id) do nothing;

-- Allow public access to read logos
create policy "Public can view logos"
on storage.objects for select
to public
using ( bucket_id = 'logos' );

-- Allow authenticated users to upload logos
create policy "Authenticated users can upload logos"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'logos' 
  and (auth.role() = 'authenticated')
);

-- Allow authenticated admins to delete logos
create policy "Admins can delete logos"
on storage.objects for delete
to authenticated
using (
  bucket_id = 'logos'
  and exists (
    select 1 from public.profiles p
    join public.roles r on r.id = p.role_id
    where p.id = auth.uid()
    and r.name in ('admin', 'super_admin')
  )
);