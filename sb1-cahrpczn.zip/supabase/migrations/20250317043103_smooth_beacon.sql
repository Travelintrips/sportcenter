/*
  # Add Phone Number to Profiles

  1. Changes
    - Add phone_number column to profiles table
    - Make it optional to support existing users
    
  2. Security
    - Maintain existing RLS policies
*/

-- Add phone_number column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'profiles' 
    AND column_name = 'phone_number'
  ) THEN
    ALTER TABLE profiles
    ADD COLUMN phone_number text;
  END IF;
END $$;