/*
  # Add Email Notification Trigger

  1. Changes
    - Add trigger function to handle email notifications
    - Create trigger for booking status changes
    - Add HTTP request trigger for email notifications
    
  2. Security
    - Function runs with security definer permissions
    - Ensures proper access control
*/

-- Create or replace the trigger function
CREATE OR REPLACE FUNCTION handle_booking_notification()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  -- Insert email notification for new or updated bookings
  INSERT INTO email_notifications (
    recipient_email,
    recipient_name,
    type,
    data
  ) VALUES (
    COALESCE(NEW.customer_email, (SELECT email FROM auth.users WHERE id = NEW.user_id)),
    COALESCE(NEW.customer_name, (SELECT full_name FROM profiles WHERE id = NEW.user_id)),
    'booking_confirmation',
    jsonb_build_object(
      'facilityName', (SELECT name FROM sports_facilities WHERE id = NEW.facility_id),
      'startTime', NEW.start_time,
      'endTime', NEW.end_time,
      'totalPrice', NEW.total_price,
      'bookingReference', NEW.guest_reference,
      'customerName', COALESCE(NEW.customer_name, (SELECT full_name FROM profiles WHERE id = NEW.user_id))
    )
  );
  
  RETURN NEW;
END;
$$;

-- Create the trigger
DROP TRIGGER IF EXISTS on_booking_notification ON bookings;
CREATE TRIGGER on_booking_notification
  AFTER INSERT OR UPDATE OF status
  ON bookings
  FOR EACH ROW
  EXECUTE FUNCTION handle_booking_notification();

-- Create trigger for sending emails via Edge Function
DROP TRIGGER IF EXISTS sender_email ON email_notifications;
CREATE TRIGGER sender_email
  AFTER INSERT OR UPDATE OR DELETE
  ON email_notifications
  FOR EACH ROW
  EXECUTE FUNCTION supabase_functions.http_request(
    'https://kzibrbcrqbknckjbdrtc.supabase.co/functions/v1/send-booking-confirmation',
    'POST',
    '{"Content-type":"application/json"}',
    '{}',
    '5000'
  );