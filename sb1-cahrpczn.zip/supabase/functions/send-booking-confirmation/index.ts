//index.ts
import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.7";
import { SMTPClient } from "npm:emailjs";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Fetch all pending email notifications
    const { data: notifications, error: fetchError } = await supabaseClient
      .from("email_notifications")
      .select("*")
      .eq("status", "pending")
      .order("created_at", { ascending: true });

    if (fetchError) throw fetchError;
    if (!notifications || notifications.length === 0) {
      return new Response(
        JSON.stringify({ message: "No pending notifications" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 }
      );
    }

    // SMTP Configuration
    const client = new SMTPClient({
      user: Deno.env.get("SMTP_USER")!,
      password: Deno.env.get("SMTP_PASSWORD")!,
      host: Deno.env.get("SMTP_HOST") || "smtp.gmail.com",
      ssl: true,
    });

    for (const notification of notifications) {
      const { recipient_email, recipient_name, data } = notification;

      const emailContent = `
        <html>
        <body>
          <h2>Booking Confirmation</h2>
          <p>Dear ${recipient_name},</p>
          <p>Thank you for booking with us. Your booking has been confirmed!</p>
          <h3>Booking Details:</h3>
          <ul>
            <li><strong>Facility:</strong> ${data.facilityName}</li>
            <li><strong>Start Time:</strong> ${data.startTime}</li>
            <li><strong>End Time:</strong> ${data.endTime}</li>
            <li><strong>Total Price:</strong> ${data.totalPrice}</li>
            <li><strong>Booking Reference:</strong> ${data.bookingReference}</li>
          </ul>
          <p>If you have any questions, please contact our support team.</p>
          <p>Best regards, <br>Your Team</p>
        </body>
        </html>
      `;

      // Send email via SMTP
      await client.sendAsync({
        from: Deno.env.get("SMTP_FROM")!,
        to: recipient_email,
        subject: "Booking Confirmation",
        attachment: [{ data: emailContent, alternative: true }],
      });

      // Update email status
      await supabaseClient
        .from("email_notifications")
        .update({ status: "sent", processed_at: new Date().toISOString() })
        .eq("id", notification.id);
    }

    return new Response(
      JSON.stringify({ message: "All emails sent successfully via SMTP" }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      }
    );
  } catch (error) {
    console.error("Error sending emails:", error);

    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500,
      }
    );
  }
});
