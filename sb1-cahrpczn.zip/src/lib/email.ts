import { supabase } from './supabase';

interface SendBookingConfirmationEmailParams {
  to: string;
  customerName: string;
  facilityName: string;
  startTime: string;
  endTime: string;
  totalPrice: number;
  bookingReference?: string;
}

export async function sendBookingConfirmationEmail({
  to,
  customerName,
  facilityName,
  startTime,
  endTime,
  totalPrice,
  bookingReference
}: SendBookingConfirmationEmailParams) {
  try {
    if (!customerName) {
      throw new Error('Customer name is required for email notification');
    }

    if (!to) {
      throw new Error('Recipient email is required');
    }

    // Send email notification through database trigger instead
    const { error } = await supabase
      .from('email_notifications')
      .insert([{
        recipient_email: to,
        recipient_name: customerName,
        type: 'booking_confirmation',
        data: {
          facilityName,
          startTime,
          endTime,
          totalPrice,
          bookingReference,
          customerName
        },
        status: 'pending',
        booking_reference: bookingReference
      }]);

    if (error) {
      console.error('Error creating email notification:', error);
      throw new Error('Failed to queue email notification');
    }
  } catch (error) {
    console.error('Error queueing email notification:', error);
    throw error; // Re-throw to handle in the booking flow
  }
}