import { supabase } from '../lib/supabase';

export async function checkSlotsAvailability(
  facilityId: string,
  bookingSlots: { start: Date; end: Date }[]
): Promise<boolean> {
  for (const slot of bookingSlots) {
    const { data, error } = await supabase
      .from('bookings')
      .select('id')
      .eq('facility_id', facilityId)
      .gte('end_time', slot.start.toISOString())
      .lte('start_time', slot.end.toISOString())
      .neq('status', 'cancelled');

    if (error) throw error;

    if (data && data.length > 0) {
      // ada bentrok
      return false;
    }
  }

  return true; // semua slot tersedia
}