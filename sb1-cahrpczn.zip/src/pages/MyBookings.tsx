import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  BookOpen,
  AlertCircle,
  CalendarDays,
  Clock,
  Tag,
  CreditCard,
  ArrowLeft
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuthStore } from '../stores/authStore';

interface Booking {
  id: string;
  booking_reference?: string;
  facility_id: string;
  start_time: string;
  end_time: string;
  status: string;
  total_price: number;
  customer_name: string | null;
  customer_phone: string | null;
  customer_email: string | null;
  payment_method: {
    bank_name: string;
    account_number: string;
    account_holder: string;
  } | null;
  facility: {
    name: string;
    booking_type?: 'per_hour' | 'per_day';
  };
}

export function MyBookings() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [expandedGroups, setExpandedGroups] = useState<string[]>([]);

  useEffect(() => {
    if (!user) navigate('/login');
    else loadBookings();
  }, [user]);

  const loadBookings = async () => {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select(`
          id,
          facility_id,
          start_time,
          end_time,
          status,
          total_price,
          customer_name,
          customer_phone,
          customer_email,
          payment_method:bank_accounts!bookings_payment_method_id_fkey (
            bank_name,
            account_number,
            account_holder
          ),
          facility:sports_facilities!bookings_facility_id_fkey (
            name,
            booking_type
          )
        `)
        .eq('user_id', user.id)
        .order('start_time', { ascending: true });

      if (error) throw error;
      setBookings(data || []);
    } catch (err: any) {
      console.error('Error loading bookings:', err);
      setError('Failed to load bookings. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const groupBookings = (bookings: Booking[]) => {
    const groups: Record<string, Booking[]> = {};
    
    bookings.forEach(booking => {
      const startTime = new Date(booking.start_time);
      const key = `${booking.facility_id}-${startTime.getHours()}-${startTime.getMinutes()}`;
      
      if (!groups[key]) {
        groups[key] = [];
      }
      groups[key].push(booking);
    });

    // Sort bookings within each group by start time
    Object.values(groups).forEach(group => {
      group.sort((a, b) => new Date(a.start_time).getTime() - new Date(b.start_time).getTime());
    });

    // Sort groups by the first booking's start time
    const sortedGroups: Record<string, Booking[]> = {};
    Object.entries(groups)
      .sort(([, a], [, b]) => {
        const aTime = new Date(a[0].start_time).getTime();
        const bTime = new Date(b[0].start_time).getTime();
        return aTime - bTime;
      })
      .forEach(([key, value]) => {
        sortedGroups[key] = value;
      });

    return sortedGroups;
  };

  const toggleGroup = (ref: string) => {
    setExpandedGroups(prev =>
      prev.includes(ref) ? prev.filter(id => id !== ref) : [...prev, ref]
    );
  };

  const formatDateTime = (dateString: string) => new Date(dateString).toLocaleString('en-US', {
    year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit'
  });

  const calculateDuration = (start: string, end: string, facility: Booking['facility']) => {
    const startDate = new Date(start);
    const endDate = new Date(end);
    
    // For gym or facilities with per_day booking type
    if (facility.name.toLowerCase() === 'gym' || facility.booking_type === 'per_day') {
      const days = Math.round((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
      
      // If duration is approximately 30 days (monthly membership)
      if (days >= 28 && days <= 31) {
        return '1 Month';
      }
      
      return '1 Day Visit';
    }

    // For hourly bookings
    const hours = Math.round((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60));
    return `${hours} hour${hours > 1 ? 's' : ''}`;
  };

  const getStatusColor = (status: string) => ({
    confirmed: 'bg-green-100 text-green-800',
    cancelled: 'bg-red-100 text-red-800',
    pending: 'bg-yellow-100 text-yellow-800'
  }[status] || 'bg-gray-100 text-gray-800');

  const formatIDR = (price: number) => new Intl.NumberFormat('id-ID', {
    style: 'currency', currency: 'IDR', minimumFractionDigits: 0
  }).format(price);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  const groupedBookings = groupBookings(bookings);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header & Back Button */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 gap-4">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 flex items-center">
            <BookOpen className="h-7 w-7 mr-2 text-indigo-600" />
            My Bookings
          </h1>
          <button
            onClick={() => navigate('/')}
            className="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </button>
        </div>

        {/* Error Message */}
        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg flex items-center">
            <AlertCircle className="h-5 w-5 mr-2" />{error}
          </div>
        )}

        {bookings.length === 0 ? (
          <div className="bg-white rounded-lg shadow-sm p-8 text-center">
            <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No Bookings Found</h3>
            <p className="text-gray-500 mb-4">You haven't made any bookings yet.</p>
            <button onClick={() => navigate('/')} className="inline-flex items-center px-4 py-2 border border-transparent rounded-md text-sm font-medium text-indigo-600 bg-indigo-50 hover:bg-indigo-100">
              Browse Facilities
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            {Object.entries(groupedBookings).map(([key, group]) => {
              const first = group[0];
              const rest = group.slice(1);
              const isExpanded = expandedGroups.includes(key);

              return (
                <div key={key} className="bg-white rounded-lg shadow-sm overflow-hidden mb-6">
                  <div className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <h3 className="text-lg font-semibold text-gray-900">{first.facility.name}</h3>
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(first.status)}`}>{first.status.charAt(0).toUpperCase() + first.status.slice(1)}</span>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        {[{
                          icon: CalendarDays,
                          label: 'Schedule',
                          value: <><p className="font-medium">{formatDateTime(first.start_time)}</p><p className="font-medium">{formatDateTime(first.end_time)}</p></>
                        }, {
                          icon: Clock,
                          label: 'Duration',
                          value: <p className="font-medium">{calculateDuration(first.start_time, first.end_time, first.facility)}</p>
                        }, {
                          icon: Tag,
                          label: 'Total Price',
                          value: <p className="font-medium text-indigo-600">{formatIDR(first.total_price)}</p>
                        }].map((item, idx) => (
                          <div key={idx} className="flex items-start space-x-3">
                            <item.icon className="h-5 w-5 text-gray-400 mt-1" />
                            <div><p className="text-sm text-gray-500">{item.label}</p>{item.value}</div>
                          </div>
                        ))}
                      </div>
                      {first.payment_method && (
                        <div className="bg-gray-50 rounded-lg p-4">
                          <h4 className="font-medium text-gray-900 mb-3 flex items-center">
                            <CreditCard className="h-5 w-5 mr-2" /> Payment Method
                          </h4>
                          <div className="space-y-2 text-sm">
                            {Object.entries(first.payment_method).map(([key, val]) => (
                              <p key={key}><span className="text-gray-500 capitalize">{key.replace('_', ' ')}:</span> <span className="font-medium">{val}</span></p>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                    {rest.length > 0 && (
                      <div className="mt-4">
                        <button onClick={() => toggleGroup(key)} className="text-sm text-indigo-600 hover:underline">
                          {isExpanded ? 'Hide Details' : `Show All Bookings (${rest.length + 1} sessions)`}
                        </button>
                      </div>
                    )}
                  </div>
                  {isExpanded && rest.length > 0 && (
                    <div className="px-6 pb-6 space-y-4 border-t border-gray-100">
                      {rest.map((item) => (
                        <div key={item.id} className="pt-4 border-b border-gray-100">
                          <div className="text-sm text-gray-500">{formatDateTime(item.start_time)} → {formatDateTime(item.end_time)}</div>
                          <div className="text-sm">Duration: {calculateDuration(item.start_time, item.end_time, item.facility)}</div>
                          <div className="text-sm text-indigo-600 font-medium">{formatIDR(item.total_price)}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}