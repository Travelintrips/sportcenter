import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Users, 
  Shield, 
  ArrowLeft, 
  Plus, 
  Trash2, 
  AlertCircle, 
  X,
  UserPlus, 
  Settings, 
  Calendar,
  Search,
  Filter,
  CheckCircle,
  XCircle,
  Phone
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuthStore } from '../stores/authStore';
import { Mail } from 'lucide-react';


interface User {
  id: string;
  full_name: string;
  created_at?: string;
  is_active: boolean;
  phone_number?: string;
  role: {
    id: string;
    name: string;
  };
}

interface Role {
  id: string;
  name: string;
}

interface NewUser {
  email: string;
  password: string;
  full_name: string;
  role_id: string;
  phone_number: string;
}

interface GroupedUsers {
  superAdmin: User[];
  admin: User[];
  members: User[];
  staff: User[];
  user: User[];
}

interface Filters {
  search: string;
  role: string;
  status: 'all' | 'active' | 'inactive';
}

export function UserManagement() {
  const [editUser, setEditUser] = useState<User | null>(null);
  const navigate = useNavigate();
  const { profile } = useAuthStore();
  const [users, setUsers] = useState<User[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<User[]>([]);
  const [roles, setRoles] = useState<Role[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedUser, setSelectedUser] = useState<string | null>(null);
  const [selectedRole, setSelectedRole] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);
  const [userRole, setUserRole] = useState<string>('');
  const [filters, setFilters] = useState<Filters>({
    search: '',
    role: 'all',
    status: 'all'
  });
  const [newUser, setNewUser] = useState<NewUser>({
    email: '',
    password: '',
    full_name: '',
    role_id: '',
    phone_number: ''
  });

  useEffect(() => {
    checkAccess();
  }, [profile]);

  useEffect(() => {
    filterUsers();
  }, [filters, users]);

  const checkAccess = async () => {
    try {
      if (!profile?.role_id) {
        navigate('/dashboard');
        return;
      }

      const { data: roleData } = await supabase
        .from('roles')
        .select('name')
        .eq('id', profile.role_id)
        .single();

      if (!roleData || !['super_admin', 'admin'].includes(roleData.name)) {
        navigate('/dashboard');
        return;
      }

      setUserRole(roleData.name);
      loadUsers();
      loadRoles();
    } catch (error) {
      console.error('Error checking access:', error);
      navigate('/dashboard');
    }
  };

  const loadUsers = async () => {
    try {
      const { data, error: usersError } = await supabase
  .from('profiles')
  .select(`
    id,
    email,
    full_name,
    created_at,
    is_active,
    phone_number,
    role:roles (
      id,
      name
    )
  `);


      if (usersError) throw usersError;
      setUsers(data || []);
      setFilteredUsers(data || []);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const loadRoles = async () => {
    try {
      const { data, error } = await supabase
        .from('roles')
        .select('*')
        .order('name');

      if (error) throw error;
      setRoles(data || []);
    } catch (err: any) {
      setError(err.message);
    }
  };

  const filterUsers = () => {
    let result = [...users];

    // Apply search filter
    if (filters.search) {
      const searchTerm = filters.search.toLowerCase();
      result = result.filter(user => 
        user.full_name.toLowerCase().includes(searchTerm) ||
        user.role.name.toLowerCase().includes(searchTerm) ||
        (user.phone_number && user.phone_number.includes(searchTerm))
      );
    }

    // Apply role filter
    if (filters.role !== 'all') {
      result = result.filter(user => user.role.name === filters.role);
    }

    // Apply status filter
    if (filters.status !== 'all') {
      const isActive = filters.status === 'active';
      result = result.filter(user => user.is_active === isActive);
    }

    setFilteredUsers(result);
  };

  const updateUserRole = async () => {
    if (!selectedUser || !selectedRole) return;

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ role_id: selectedRole })
        .eq('id', selectedUser);

      if (error) throw error;

      loadUsers();
      setSelectedUser(null);
      setSelectedRole(null);
    } catch (err: any) {
      setError(err.message);
    }
  };

  const toggleUserStatus = async (userId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ is_active: !currentStatus })
        .eq('id', userId);

      if (error) throw error;
      loadUsers();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const deleteUser = async (userId: string) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .delete()
        .eq('id', userId);

      if (error) throw error;
      loadUsers();
      setShowDeleteConfirm(null);
    } catch (err: any) {
      setError(err.message);
    }
  };

  const createUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    try {
      // Sign up the user
      const { data: { user }, error: signUpError } = await supabase.auth.signUp({
        email: newUser.email,
        password: newUser.password,
      });

      if (signUpError) throw signUpError;
      if (!user) throw new Error('No user returned after signup');

      // Create profile with selected role
      const { error: profileError } = await supabase
  .from('profiles')
  .insert({
    id: user.id,
    email: newUser.email, // ← disimpan manual
    role_id: newUser.role_id,
    full_name: newUser.full_name,
    phone_number: newUser.phone_number,
    is_active: true
  });

      if (profileError) throw profileError;

      // Reset form and close modal
      setNewUser({
        email: '',
        password: '',
        full_name: '',
        role_id: '',
        phone_number: ''
      });
      setShowCreateModal(false);
      loadUsers();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const groupUsersByRole = (): GroupedUsers => {
    return filteredUsers.reduce((acc: GroupedUsers, user) => {
      // If user is admin, exclude super_admin users
      if (userRole === 'admin' && user.role?.name === 'super_admin') {
        return acc;
      }

      const roleName = user.role?.name || 'user';
      switch (roleName) {
        case 'super_admin':
          acc.superAdmin.push(user);
          break;
        case 'admin':
          acc.admin.push(user);
          break;
        case 'staff':
        acc.staff.push(user); // ← tambahkan ini
        break;  
        case 'members':
          acc.members.push(user);
          break;  
        default:
          acc.user.push(user);
      }
      return acc;
    }, { superAdmin: [], admin: [], members: [], staff: [], user: [] }); // ← pastikan semua didefinisikan
};

  const formatDate = (dateString?: string) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getRoleBadgeColor = (roleName: string) => {
    switch (roleName) {
      case 'super_admin':
        return 'bg-purple-100 text-purple-800';
      case 'admin':
        return 'bg-blue-100 text-blue-800';
      case 'members':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const UserCard = ({ user }: { user: User }) => (
  <div className={`bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow duration-200 ${!user.is_active ? 'opacity-60' : ''}`}>
    <div className="flex items-start justify-between mb-4">
      <div className="flex items-center space-x-3">
        <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
          <UserPlus className="h-6 w-6 text-gray-600" />
        </div>
        <div>
          <h3 className="text-lg font-medium text-gray-900">{user.full_name}</h3>
          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
            user.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
          }`}>
            {user.is_active ? 'Active' : 'Inactive'}
          </span>
        </div>
      </div>
      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getRoleBadgeColor(user.role?.name)}`}>
        {user.role?.name}
      </span>
    </div>

    <div className="space-y-3">
  <div className="flex items-center text-sm text-gray-500">
    <Calendar className="h-4 w-4 mr-2" />
    Joined {formatDate(user.created_at)}
  </div>

  {user.email && (
    <div className="flex items-center text-sm text-gray-500">
      <Mail className="h-4 w-4 mr-2" />
      {user.email}
    </div>
  )}

  {user.phone_number && (
    <div className="flex items-center text-sm text-gray-500">
      <Phone className="h-4 w-4 mr-2" />
      {user.phone_number}
    </div>
  )}

      <div className="flex space-x-2">
        <button
          onClick={() => setEditUser(user)}
          className="flex-1 flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-indigo-700 bg-white hover:bg-indigo-50"
        >
          <Settings className="h-4 w-4 mr-2" />
          Edit
        </button>
        <button
          onClick={() => setSelectedUser(user.id)}
          className="flex-1 flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
        >
          <Shield className="h-4 w-4 mr-2" />
          Role
        </button>
        <button
          onClick={() => toggleUserStatus(user.id, user.is_active)}
          className={`flex items-center justify-center px-4 py-2 border rounded-md shadow-sm text-sm font-medium ${
            user.is_active 
              ? 'border-red-300 text-red-700 hover:bg-red-50'
              : 'border-green-300 text-green-700 hover:bg-green-50'
          }`}
        >
          {user.is_active ? <XCircle className="h-4 w-4" /> : <CheckCircle className="h-4 w-4" />}
        </button>
        <button
          onClick={() => setShowDeleteConfirm(user.id)}
          className="flex items-center justify-center px-4 py-2 border border-red-300 rounded-md shadow-sm text-sm font-medium text-red-700 hover:bg-red-50"
        >
          <Trash2 className="h-4 w-4" />
        </button>
      </div>
    </div>
  </div>
);


  const UserSection = ({ title, users, icon: Icon }: { title: string; users: User[]; icon: any }) => (
    <div className="mb-8">
      <div className="flex items-center mb-4">
        <Icon className="h-5 w-5 text-gray-600 mr-2" />
        <h2 className="text-lg font-medium text-gray-900">{title}</h2>
        <span className="ml-2 text-sm text-gray-500">({users.length})</span>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {users.map(user => (
          <UserCard key={user.id} user={user} />
        ))}
        {users.length === 0 && (
          <div className="col-span-full bg-gray-50 rounded-lg p-6 text-center">
            <p className="text-gray-500">No users found in this category</p>
          </div>
        )}
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  const groupedUsers = groupUsersByRole();

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center">
            <button
              onClick={() => navigate('/settings')}
              className="mr-4 p-2 hover:bg-gray-100 rounded-full transition-colors duration-200"
            >
              <ArrowLeft className="h-6 w-6 text-gray-600" />
            </button>
            <Users className="h-8 w-8 text-indigo-600 mr-3" />
            <h1 className="text-3xl font-bold text-gray-900">User Management</h1>
          </div>
          <button
            onClick={() => setShowCreateModal(true)}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700"
          >
            <Plus className="h-5 w-5 mr-2" />
            Create User
          </button>
        </div>

        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg flex items-center">
            <AlertCircle className="h-5 w-5 mr-2" />
            {error}
          </div>
        )}

        {/* Filters */}
        <div className="bg-white p-4 rounded-lg shadow-sm mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search users..."
                  value={filters.search}
                  onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                  className="pl-10 w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-48">
                <select
                  value={filters.role}
                  onChange={(e) => setFilters({ ...filters, role: e.target.value })}
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                >
                  <option value="all">All Roles</option>
                  {roles.map((role) => (
                    <option key={role.id} value={role.name}>
                      {role.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="w-48">
                <select
                  value={filters.status}
                  onChange={(e) => setFilters({ ...filters, status: e.target.value as 'all' | 'active' | 'inactive' })}
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                >
                  <option value="all">All Status</option>
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {userRole === 'super_admin' && (
          <UserSection title="Super Administrators" users={groupedUsers.superAdmin} icon={Shield} />
        )}
        <UserSection title="Administrators" users={groupedUsers.admin} icon={Users} />
        <UserSection title="Members" users={groupedUsers.members} icon={UserPlus} />
        <UserSection title="Staff" users={groupedUsers.staff} icon={Users} />
        <UserSection title="Regular Users" users={groupedUsers.user} icon={Users} />
      </div>

      {/* Create User Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <Shield className="h-6 w-6 text-indigo-600 mr-2" />
                <h3 className="text-lg font-medium text-gray-900">Create New User</h3>
              </div>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-gray-400 hover:text-gray-500"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={createUser} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={newUser.full_name}
                  onChange={(e) => setNewUser({ ...newUser, full_name: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Email
                </label>
                <input
                  type="email"
                  required
                  value={newUser.email}
                  onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={newUser.phone_number}
                  onChange={(e) => setNewUser({ ...newUser, phone_number: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                  placeholder="+62 xxx-xxxx-xxxx"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Password
                </label>
                <input
                  type="password"
                  required
                  value={newUser.password}
                  onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Role
                </label>
                <select
                  required
                  value={newUser.role_id}
                  onChange={(e) => setNewUser({ ...newUser, role_id: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                >
                  <option value="">Select a role</option>
                  {roles.map((role) => (
                    <option key={role.id} value={role.id}>
                      {role.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="mt-6 flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700"
                >
                  Create User
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Change Role Modal */}
{editUser && (
  <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
    <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          <UserPlus className="h-6 w-6 text-indigo-600 mr-2" />
          <h3 className="text-lg font-medium text-gray-900">Edit User</h3>
        </div>
        <button
          onClick={() => setEditUser(null)}
          className="text-gray-400 hover:text-gray-500"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      <form
  onSubmit={async (e) => {
    e.preventDefault();
    if (!editUser) return;

    try {
      // 1. Update nama dan no HP ke tabel `profiles`
      const { error } = await supabase
        .from('profiles')
        .update({
          full_name: editUser.full_name,
          phone_number: editUser.phone_number,
          email: editUser.email,
        })
        .eq('id', editUser.id);

      if (error) throw error;

      // 2. Panggil Edge Function untuk update email di auth.users
      const res = await fetch('https://kzibrbcrqbknckjbdrtc.supabase.co/functions/v1/update-user-email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`, // atau SERVICE_ROLE jika dari backend
        },
        body: JSON.stringify({ id: editUser.id, email: editUser.email }),
      });

      const result = await res.json();
      if (!res.ok) throw new Error(result.error || 'Failed to update email');

      // 3. Refresh data & tutup modal
      loadUsers();
      setEditUser(null);
    } catch (err: any) {
      setError(err.message);
    }
  }}
  className="space-y-4"
>

        <div>
          <label className="block text-sm font-medium text-gray-700">Full Name</label>
          <input
            type="text"
            required
            value={editUser.full_name}
            onChange={(e) =>
              setEditUser({ ...editUser, full_name: e.target.value })
            }
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Email</label>
          <input
  type="email"
  required
  title="Please enter a valid email address"
  value={editUser.email}
  onChange={(e) =>
    setEditUser({ ...editUser, email: e.target.value })
  }
  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
/>


        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Phone</label>
          <input
            type="text"
            value={editUser.phone_number || ''}
            onChange={(e) =>
              setEditUser({ ...editUser, phone_number: e.target.value })
            }
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          />
        </div>
        <div className="mt-4 flex justify-end space-x-3">
          <button
            onClick={() => setEditUser(null)}
            type="button"
            className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700"
          >
            Save
          </button>
        </div>
      </form>
    </div>
  </div>
)}
      
      {selectedUser && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <div className="flex items-center mb-4">
              <Shield className="h-6 w-6 text-indigo-600 mr-2" />
              <h3 className="text-lg font-medium text-gray-900">Change User Role</h3>
            </div>
            
            <select
              value={selectedRole || ''}
              onChange={(e) => setSelectedRole(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            >
              <option value="">Select a role</option>
              {roles.map((role) => (
                <option key={role.id} value={role.id}>
                  {role.name}
                </option>
              ))}
            </select>

            <div className="mt-4 flex justify-end space-x-3">
              <button
                onClick={() => setSelectedUser(null)}
                className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={updateUserRole}
                className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700"
              >
                Update Role
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <div className="flex items-center mb-4">
              <AlertCircle className="h-6 w-6 text-red-600 mr-2" />
              <h3 className="text-lg font-medium text-gray-900">Confirm Delete</h3>
            </div>
            
            <p className="text-gray-500 mb-4">
              Are you sure you want to delete this user? This action cannot be undone.
            </p>

            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setShowDeleteConfirm(null)}
                className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={() => showDeleteConfirm && deleteUser(showDeleteConfirm)}
                className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700"
              >
                Delete User
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}